# Put Coco’s Quest online (free)

This folder is the whole game as a website. Upload it and you get a link anyone can open, with no Claude account.

## Fastest: Netlify Drop
1. Unzip this file so you have a folder with index.html inside.
2. Go to netlify.com/drop and drag the folder onto the page.
3. You get a live link right away. IMPORTANT: sign up for a free Netlify account and click "Claim" within the hour, or the site is deleted.
4. To update later, drag a new folder onto the site’s Deploys page.

## Also fast: Cloudflare Drop
1. Go to cloudflare.com/drop and drag the ZIP (or the folder) onto the page.
2. Claim the site with a free Cloudflare account before the preview expires, or it is deleted.

## Permanent and free: GitHub Pages
Create a public repository, upload these files, then turn on Pages in the repository settings.

## After it is online
- Share the link with friends. On a phone, they can tap Share > "Add to Home Screen" to play full screen like an app.
- Your privacy policy is at YOUR-LINK/privacy.html. Fill in the date and email in privacy.html first. Use that address for the App Store and Google Play listings, and in the app project (PRIVACY_URL in www/index.html).
- This website version is single-player. Seeing friends in the same world only works inside Claude.
